const splash = document.querySelector('.splash-screen');
const hero = document.querySelector('.main');

window.onload = function(){
  splash.style.opacity = '0';
  splash.addEventListener('transitionend', () => splash.remove());
  hero.style.opacity = '1';
};